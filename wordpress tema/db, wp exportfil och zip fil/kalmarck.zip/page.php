<?php

get_header();

get_template_part('template-parts/content', 'mainsection' );

get_template_part('template-parts/content', 'upptack' );

get_template_part('template-parts/content', 'pagang' );

get_template_part('template-parts/content', 'verksamhet' );

get_template_part('template-parts/content', 'omoss' );

get_template_part('template-parts/content', 'kontakt' );

get_footer();

?>
